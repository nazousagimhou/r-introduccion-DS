rm(list=ls())
setwd("~")

############################
# Oscar Elton              #
# gráficas con ggplot      #
# 01/08/2017               #
############################

require(foreign)
require(plyr)
require(tidyverse)
require(readstata13)
require(reshape2)
require(readxl)
require(stats)

dir1 <- "/Users/oscareltons/Dropbox (Data4)/Batch 15/ggplot2/Inp"
dir2 <- "/Users/oscareltons/Dropbox (Data4)/Batch 15/ggplot2/Out"

# Limpiar desaparecidos
data <- read_excel(paste(dir1, "Datos_abiertos_RNPED_Fuero_comun.xls", sep="/"), col_types = c("date", "date", "text", "text", "text", "text", "text",
                                                                                               "numeric", "text", "text", "numeric", "text", "text", "text",
                                                                                               "text"))
# Cambiar nombres
names(data) <- c("fecha", "hora", "pais", "entidad", "municipio", "localidad", "nacionalidad", "estatura", "complexion", "sexo", "edad", "descripcion", "etnia", "discapacidad", "dependencia")

data <- data %>%
        mutate(fecha = as.character(fecha),
               hora = as.character(hora))

cheat <- read_excel(paste(dir1, "CheetSheet.xlsx", sep="/"))
cheat <- cheat %>%
         rename(ent = edo,
                entidad = edoname,
                mun = mun,
                municipio = munname) %>%
         right_join(data, by=c("entidad", "municipio"))



drop <- subset(cheat, is.na(cheat$ent)==T)
table(drop$entidad, useNA = "ifany")
rm(drop)

tempo <- subset(cheat, entidad!="NO ESPECIFICADO")
rm(cheat)
drop <- subset(tempo, is.na(tempo$ent)==T)
drop$entmun <- paste(drop$municipio, drop$entidad, sep=", ")
x <- names(table(drop$entmun, useNA = "ifany"))
x <- as.data.frame(x)
write.csv(x, paste(dir1, "faltan.csv", sep="/"), row.names = F)
rm(x, drop, data)

# Meter a mano códigos que faltan
faltan <- read_csv(paste(dir1, "faltan.csv", sep="/"))

faltan <- faltan %>%
          rename(entmun = x) %>%
          separate(entmun, c("municipio", "entidad"), sep=", ")

names(table(faltan$entidad))

tempo <- tempo %>%
  mutate(ent = ifelse(entidad=="CHIAPAS", 7, 
               ifelse(entidad=="CHIHUAHUA", 8,
               ifelse(entidad=="CIUDAD DE MEXICO", 9,
               ifelse(entidad=="COAHUILA DE ZARAGOZA", 5,
               ifelse(entidad=="COLIMA", 6,
               ifelse(entidad=="DURANGO", 10,
               ifelse(entidad=="ESTADO DE MEXICO", 15,
               ifelse(entidad=="GUANAJUATO", 11,        
               ifelse(entidad=="GUERRERO", 12,
               ifelse(entidad=="HIDALGO", 13,
               ifelse(entidad=="JALISCO", 14,
               ifelse(entidad=="MICHOACAN", 16,
               ifelse(entidad=="NUEVO LEON", 19,
               ifelse(entidad=="OAXACA", 20,
               ifelse(entidad=="PUEBLA", 21,
               ifelse(entidad=="QUERETARO", 22,
               ifelse(entidad=="QUINTANA ROO", 23,
               ifelse(entidad=="SAN LUIS POTOSI", 24,
               ifelse(entidad=="SINALOA", 25,
               ifelse(entidad=="SONORA", 26,
               ifelse(entidad=="TABASCO", 27,       
               ifelse(entidad=="TAMAULIPAS", 28,
               ifelse(entidad=="TLAXCALA", 29,
               ifelse(entidad=="VERACRUZ", 30,
               ifelse(entidad=="ZACATECAS", 32, ent)))))))))))))))))))))))))) %>%
  arrange(ent, entidad)

names(table(faltan$municipio))

tempo <- tempo %>%
         mutate(mun = ifelse(ent==15 & municipio=="ACULCO", 3,
                      ifelse(ent==15 & municipio=="AMATEPEC", 8,
                      ifelse(ent==32 & municipio=="APOZOL", 1,
                      ifelse(ent==7 & municipio=="ARRIAGA", 9,
                      ifelse(ent==31 & municipio=="BACA", 4,
                      ifelse(ent==7 & municipio=="BELLA VISTA", 11,
                      ifelse(ent==7 & municipio=="BERRIOZABAL", 12,
                      ifelse(ent==7 & municipio=="CACAHOATAN", 15,
                      ifelse(ent==21 & municipio=="CHIAUTLA", 47,
                      ifelse(ent==21 & municipio=="CHIAUTZINGO", 48,
                      ifelse(ent==31 & municipio=="CHICHIMILA", 21,
                      ifelse(ent==21 & municipio=="CHILCHOTLA", 58,
                      ifelse(ent==7 & municipio=="COMITAN DE DOMINGUEZ", 19,
                      ifelse(ent==32 & municipio=="CONCEPCION DEL ORO", 7,
                      ifelse(ent==21 & municipio=="CORONANGO", 34,
                      ifelse(ent==21 & municipio=="COXCATLAN", 35,
                      ifelse(ent==31 & municipio=="DZITAS", 30,
                      ifelse(ent==7 & municipio=="ESCUINTLA", 32,
                      ifelse(ent==21 & municipio=="ESPERANZA", 63,
                      ifelse(ent==21 & municipio=="FRANCISCO Z. MENA", 64,
                      ifelse(ent==7 & municipio=="FRONTERA HIDALGO", 35,
                      ifelse(ent==32 & municipio=="HUANUSCO", 18,
                      ifelse(ent==31 & municipio=="IZAMAL", 40,
                      ifelse(ent==15 & municipio=="JOQUICINGO", 49,
                      ifelse(ent==12 & municipio=="JOSE JOAQUIN DE HERRERA", 79,
                      ifelse(ent==7 & municipio=="MAPASTEPEC", 51,
                      ifelse(ent==19 & municipio=="MIER Y NORIEGA", 36,
                      ifelse(ent==15 & municipio=="OTZOLOAPAN", 66,
                      ifelse(ent==21 & municipio=="PALMAR DE BRAVO", 110,
                      ifelse(ent==19 & municipio=="PARAS", 40,
                      ifelse(ent==15 & municipio=="POLOTITLAN", 71,
                      ifelse(ent==7 & municipio=="REFORMA", 74,
                      ifelse(ent==14 & municipio=="SAN MARCOS", 75,
                      ifelse(ent==31 & municipio=="SEYE", 67,
                      ifelse(ent==31 & municipio=="SUCILA", 70,
                      ifelse(ent==21 & municipio=="TECALI DE HERRERA", 153,
                      ifelse(ent==15 & municipio=="TEQUIXQUIAC", 96,
                      ifelse(ent==21 & municipio=="TIANGUISMANALCO", 175,
                      ifelse(ent==29 & municipio=="TLAXCO", 34,
                      ifelse(ent==15 & municipio=="TONATICO", 107,
                      ifelse(ent==31 & municipio=="TUNKAS", 97,
                      ifelse(ent==7 & municipio=="TUXTLA CHICO", 102,
                      ifelse(ent==31 & municipio=="TZUCACAB", 98,
                      ifelse(ent==21 & municipio=="XAYACATLAN DE BRAVO", 196,
                      ifelse(ent==29 & municipio=="ZACATELCO", 44,
                      ifelse(ent==14 & municipio=="ZAPOTLAN DEL REY", 123, mun))))))))))))))))))))))))))))))))))))))))))))))) %>%
         arrange(ent, mun) %>%
         mutate(ent = formatC(ent, width = 2, format = "d", flag = "0"),
                mun = formatC(mun, width = 3, format = "d", flag = "0"),
                inegi = paste0(ent, mun),
                edad = as.integer(edad),
                rango_edad = ifelse(edad %in% 0:11, "0 a 11 años",
                             ifelse(edad %in% 12:17, "12 a 17 años",
                             ifelse(edad %in% 18:25, "18 a 25 años",
                             ifelse(edad %in% 26:40, "26 a 40 años",
                             ifelse(edad %in% 41:64, "41 a 64 años",
                             ifelse(edad %in% 65:110, "65 o más años", NA)))))),
                total = 1,
                year = substr(fecha, 1, 4),
                year = as.integer(year)) %>%
          group_by(inegi, ent, mun, year, sexo, rango_edad) %>%
          summarise(total = sum(total)) %>%
          ungroup()

tempo$sexo[tempo$sexo=="HOMBRE"] <- "Hombre"
tempo$sexo[tempo$sexo=="MUJER"] <- "Mujer"

# Pegamos población para poder sacar tasas
pob <- read_csv(paste(dir1, "pobmunsex.csv", sep="/"))

data <- merge(tempo, pob, by=c("inegi", "year", "sexo", "rango_edad"), all=T)
rm(tempo, pob)

data <- data %>%
        filter(year>=2010 & year<=2015,
               !is.na(rango_edad),
               !is.na(pob)) %>%
        mutate(ent = substr(inegi, 1, 2),
               mun = substr(inegi, 3, 5),
               total = ifelse(is.na(total)==T, 0, total),
               tdes = round((total/pob)*100000, 2))

# Pegar nombres de municipios
muns <- read_excel(paste(dir1, "Municipios2016.xlsx", sep="/"))

muns <- muns %>%
        rename(ent = CVE_ENT,
               nom_ent = NOM_ENT,
               mun = CVE_MUN,
               nom_mun = NOM_MUN) %>%
        mutate(ent = formatC(ent, width = 2, format = "d", flag = "0"),
               mun = formatC(mun, width = 3, format = "d", flag = "0"))

data <- data %>%
        left_join(muns, by=c("ent", "mun"))

data <- data[, c("inegi", "ent", "nom_ent", "mun", "nom_mun","year","sexo","rango_edad","pob","total", "tdes")]

write.csv(data, paste(dir2, "rnped_limpia.csv", sep="/"), row.names = F, fileEncoding = "UTF-8")
